/*******************************************************************************
    Copyright (c) The Taichi MPM Authors (2018- ). All Rights Reserved.
    The use of this software is governed by the LICENSE file.
*******************************************************************************/

#include "boundary_particle.h"

TC_NAMESPACE_BEGIN

TC_REGISTER_MPM_PARTICLE(RigidBoundary);

TC_NAMESPACE_END
